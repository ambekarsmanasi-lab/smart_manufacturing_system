"""
Generate simulated telemetry for the Machine Monitor dashboard.

This script ONLY inserts rows into sensor_readings in smart_manufacturing_erp.
It does not create, update, resolve, classify, or otherwise modify faults.
Run from this directory with: python simulator.py
Stop with Ctrl+C.
"""
import os
import random
import time
from datetime import datetime

import mysql.connector
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME", "smart_manufacturing_erp"),
}

# (baseline, noise standard deviation), keyed by lower-case sensor_type.
SENSOR_PROFILES = {
    "spindle temperature": (58.0, 4.0),
    "vibration": (2.0, 0.45),
    "spindle load": (48.0, 12.0),
    "belt speed": (1.2, 0.08),
    "joint temperature": (55.0, 4.0),
    "motor current": (3.2, 0.35),
    "barrel temperature": (185.0, 5.0),
    "injection pressure": (95.0, 8.0),
    "seal temperature": (170.0, 4.0),
    "throughput": (42.0, 3.0),
}


def connect():
    if not DB_CONFIG["password"]:
        raise RuntimeError(
            "DB_PASSWORD is missing. Add it to machine_monitor/.env."
        )
    return mysql.connector.connect(**DB_CONFIG)


def load_sensors(conn):
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute("""
            SELECT s.sensor_id, s.sensor_type, s.unit,
                   m.machine_id, m.name AS machine_name,
                   pl.name AS line_name
            FROM sensors s
            JOIN machines m ON m.machine_id = s.machine_id
            LEFT JOIN production_lines pl ON pl.line_id = m.line_id
            ORDER BY pl.name, m.name, s.sensor_id
        """)
        rows = cur.fetchall()
    finally:
        cur.close()

    if not rows:
        raise RuntimeError(
            "No sensors were found in smart_manufacturing_erp.sensors."
        )
    return rows


def generate_value(sensor):
    key = str(sensor.get("sensor_type", "")).strip().lower()
    baseline, noise = SENSOR_PROFILES.get(key, (10.0, 1.0))
    return round(max(0.0, random.gauss(baseline, noise)), 3)


def main():
    interval = float(os.getenv("SIMULATOR_INTERVAL", "2"))
    if interval < 0.5:
        raise ValueError("SIMULATOR_INTERVAL must be at least 0.5 seconds.")

    conn = connect()
    try:
        sensors = load_sensors(conn)
        print("Connected to smart_manufacturing_erp.")
        print(f"Loaded {len(sensors)} sensors.")
        print(f"Inserting sensor readings every {interval:g} seconds.")
        print("This simulator writes ONLY to sensor_readings. Press Ctrl+C to stop.\n")

        cycle = 0
        while True:
            cur = conn.cursor()
            try:
                now = datetime.now()
                rows = [
                    (sensor["sensor_id"], now, generate_value(sensor))
                    for sensor in sensors
                ]
                cur.executemany("""
                    INSERT INTO sensor_readings (sensor_id, recorded_at, value)
                    VALUES (%s, %s, %s)
                """, rows)
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                cur.close()

            cycle += 1
            if cycle == 1 or cycle % 5 == 0:
                print(
                    f"[{datetime.now():%H:%M:%S}] cycle={cycle}, "
                    f"inserted={len(sensors)} readings"
                )
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nSimulator stopped.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
