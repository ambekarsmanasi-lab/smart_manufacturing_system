const $ = (id) => document.getElementById(id);

const MACHINE_TYPES = {
  "CNC-01": "CNC",
  "Conveyor-A": "CONVEYOR",
  "RobotArm-01": "ROBOT ARM",
  "Injection-01": "INJECTION MOLDING",
  "Conveyor-B": "CONVEYOR",
  "Packaging-01": "PACKAGING"
};

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function formatTime(value) {
  if (!value) return "NO DATA";
  const date = new Date(String(value).replace(" ", "T"));
  return Number.isNaN(date.getTime())
    ? String(value)
    : date.toLocaleTimeString([], {
        hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true
      });
}

function stateClass(state) {
  const normalized = String(state || "UNKNOWN").toLowerCase();
  return ["running", "idle", "down", "offline", "unknown"].includes(normalized)
    ? normalized : "unknown";
}

function makeCard(machine, readings, faults) {
  const machineReadings = readings.filter(
    (reading) => Number(reading.machine_id) === Number(machine.machine_id)
  );
  const machineFaults = faults.filter(
    (fault) => String(fault.machine_name) === String(machine.machine_name)
  );
  const state = machine.state || "UNKNOWN";
  const type = MACHINE_TYPES[machine.machine_name] || "MACHINE";
  const chips = machineReadings.map((reading) => {
    const value = reading.value == null ? "—" : Number(reading.value).toFixed(2);
    return `<span class="sensor-chip">
      ${esc(reading.sensor_type)}: <b>${value}${reading.unit ? ` ${esc(reading.unit)}` : ""}</b>
      <span class="sensor-time">${esc(formatTime(reading.recorded_at))}</span>
    </span>`;
  }).join("");

  const alarmMarkup = machineFaults.map((fault) => {
    const label = fault.summary || fault.fault_name || "Active alarm";
    return `<div class="machine-warning">⚠ ${esc(fault.severity || "ALARM")} · ${esc(label)}</div>`;
  }).join("");

  return `<article class="machine-card">
    <div class="machine-top">
      <div>
        <div class="machine-name">${esc(machine.machine_name)}</div>
        <div class="machine-type">${esc(type)} · ${Number(machine.sensor_count || 0)} SENSORS</div>
      </div>
      <span class="state ${stateClass(state)}" title="${esc(machine.state_reason || "")}">${esc(state)}</span>
    </div>
    <div class="state-meta">${esc(machine.state_reason || "State is not available.")}</div>
    <div class="telemetry-title">LATEST SENSOR READINGS</div>
    <div class="sensor-list">${chips || '<span class="sensor-chip">No sensor records yet</span>'}</div>
    ${alarmMarkup}
  </article>`;
}

function updateSummary(data, machines, readings, faults) {
  const summary = data.summary || {};
  const running = machines.filter((machine) => machine.state === "RUNNING").length;
  const reporting = readings.filter((reading) => reading.recorded_at).length;

  // OEE is deliberately not fabricated: no OEE model/production-count source is wired in.
  $("avgOee").textContent = "N/A";
  $("runningCount").textContent = `${running} / ${machines.length}`;
  $("alarmCount").textContent = String(summary.active_faults ?? faults.length);
  $("onlineCount").textContent = `${reporting} / ${readings.length}`;
}

async function refresh() {
  try {
    const response = await fetch("/api/overview", { cache: "no-store" });
    if (!response.ok) throw new Error(`API ${response.status}`);
    const data = await response.json();

    const machines = data.machines || [];
    const readings = data.readings || [];
    const faults = data.faults || [];

    const lineA = machines.filter((machine) =>
      String(machine.line_name || "").toUpperCase().includes("LINE A")
    );
    const lineB = machines.filter((machine) =>
      String(machine.line_name || "").toUpperCase().includes("LINE B")
    );

    $("lineA").innerHTML = lineA.length
      ? lineA.map((machine) => makeCard(machine, readings, faults)).join("")
      : '<div class="empty">No machines assigned to Line A.</div>';

    $("lineB").innerHTML = lineB.length
      ? lineB.map((machine) => makeCard(machine, readings, faults)).join("")
      : '<div class="empty">No machines assigned to Line B.</div>';

    updateSummary(data, machines, readings, faults);
    $("lineACount").textContent = `${lineA.length} MACHINES`;
    $("lineBCount").textContent = `${lineB.length} MACHINES`;
    $("updated").textContent = `UPDATED ${new Date().toLocaleTimeString()}`;
    $("error").textContent = "";
  } catch (error) {
    $("error").textContent =
      `UPLINK FAILURE :: ${error.message} — check MySQL, .env, and machine_monitor/app.py`;
  }
}

function tick() {
  $("clock").textContent = new Date().toLocaleTimeString([], {
    hour: "numeric", minute: "2-digit", second: "2-digit", hour12: true
  });
}

tick();
setInterval(tick, 1000);
refresh();
setInterval(refresh, 2500);
